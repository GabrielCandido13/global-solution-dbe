package br.com.fiap.greenfarm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenFarmApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenFarmApplication.class, args);
	}

}
